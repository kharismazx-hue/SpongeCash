package com.example.spongecash

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private val Ocean = Color(0xFFB9ECF5)
private val Sponge = Color(0xFFFFE45C)
private val DeepBlue = Color(0xFF087E9B)
private val Coral = Color(0xFFFF8E80)
private val Ink = Color(0xFF173B4A)

data class Entry(val title: String, val amount: Long, val income: Boolean, val category: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpongeCashApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpongeCashApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sponge_cash", 0) }
    fun loadEntries(): List<Entry> {
        val raw = prefs.getString("entries", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Entry(o.getString("title"), o.getLong("amount"), o.getBoolean("income"),
                    o.getString("category"), o.getString("date"))
            }
        } catch (_: Exception) { emptyList() }
    }
    var entries by remember { mutableStateOf(loadEntries()) }
    var showAdd by remember { mutableStateOf(false) }
    fun persist(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().put("title", e.title).put("amount", e.amount)
                .put("income", e.income).put("category", e.category).put("date", e.date))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
        entries = list
    }
    val incomeTotal = entries.filter { it.income }.sumOf { it.amount }
    val expenseTotal = entries.filter { !it.income }.sumOf { it.amount }
    val balance = incomeTotal - expenseTotal
    val rupiah = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    MaterialTheme(colorScheme = lightColorScheme(primary = DeepBlue, secondary = Sponge, background = Ocean)) {
        Scaffold(
            containerColor = Ocean,
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = Sponge, contentColor = Ink) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah transaksi")
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Column {
                        Text("🍍 SPONGE CASH", fontSize = 27.sp, fontWeight = FontWeight.Black, color = DeepBlue)
                        Text("Catatan keuangan Bikini Bottom", color = Ink, fontSize = 14.sp)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Sponge), shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            Text("SALDO SEKARANG", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(rupiah.format(balance), color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp)
                            Text("🌊 Kelola uangmu seperti menjaga Krabby Patty!", color = Ink, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryCard("Pemasukan", incomeTotal, Color(0xFFD7F4D2), Modifier.weight(1f), rupiah)
                        SummaryCard("Pengeluaran", expenseTotal, Color(0xFFFFDCD6), Modifier.weight(1f), rupiah)
                    }
                }
                item {
                    Text("🧾 Riwayat Transaksi", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                }
                if (entries.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("Belum ada transaksi.\nTekan tombol + untuk mulai mencatat! 🐚", color = Ink)
                            }
                        }
                    }
                } else {
                    items(entries.reversed()) { entry ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(entry.title, color = Ink, fontWeight = FontWeight.Bold)
                                    Text("${entry.category} • ${entry.date}", color = Color.Gray, fontSize = 12.sp)
                                }
                                Text((if (entry.income) "+ " else "- ") + rupiah.format(entry.amount),
                                    color = if (entry.income) Color(0xFF248044) else Color(0xFFD34C42),
                                    fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                IconButton(onClick = { persist(entries.filterNot { it === entry }) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showAdd) {
            AddEntryDialog(
                onDismiss = { showAdd = false },
                onSave = { entry -> persist(entries + entry); showAdd = false }
            )
        }
    }
}

@Composable
fun SummaryCard(label: String, amount: Long, color: Color, modifier: Modifier, format: NumberFormat) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(format.format(amount), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEntryDialog(onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Makanan") }
    var expanded by remember { mutableStateOf(false) }
    val categories = listOf("Makanan", "Transportasi", "Belanja", "Tagihan", "Hiburan", "Gaji", "Lainnya")
    val valid = title.isNotBlank() && (amount.toLongOrNull() ?: 0L) > 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Transaksi 🍍", color = DeepBlue, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Pengeluaran") })
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Pemasukan") })
                }
                OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) },
                    label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true)
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Kategori") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { category = item; expanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val date = java.text.SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID")).format(java.util.Date())
                onSave(Entry(title.trim(), amount.toLong(), income, category, date))
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = Color.White
    )
}
