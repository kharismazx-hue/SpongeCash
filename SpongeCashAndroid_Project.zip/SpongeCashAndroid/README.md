# Sponge Cash — Android Studio project

Aplikasi pencatatan pemasukan dan pengeluaran bertema bawah laut/SpongeBob-inspired.

## Fitur
- Saldo, total pemasukan, dan total pengeluaran otomatis
- Tambah pemasukan/pengeluaran dengan kategori
- Riwayat transaksi dan hapus transaksi
- Penyimpanan lokal di perangkat (SharedPreferences)

## Membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `SpongeCashAndroid` melalui Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: proyek ini adalah source project Android Studio, bukan APK yang sudah dikompilasi. Untuk build diperlukan Android Studio/Android SDK dan koneksi internet pertama kali untuk mengunduh Gradle/dependensi.
